import json

schedule = [
    {"name": "Programming and Data Processing",
     "start_time": "15:10",
     "end_time": "18:10"},
    {"name": "Calculus",
     "start_time": "9:00",
     "end_time": "11:50"},
]

# Converting to string
json_data = json.dumps(schedule)
# print(json_data)

# Writing json to a file
with open('output.json', 'w') as f:
    json.dump(schedule, f)

# Reading json from a file
with open('output.json') as f:
    restored_data = json.load(f)

print(restored_data)