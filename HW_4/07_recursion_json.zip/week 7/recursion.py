# The file contains example of recursion

def fact(n):
    if n <= 1:
        return 1
    return n * fact(n - 1)

calc_values = {}

def fib(n):
    if n <= 2:
        return 1
    if n in calc_values:
        return calc_values[n]
    calc_values[n] = fib(n-1) + fib(n-2)
    return calc_values[n]

def print_numbers(n):
    if n > 10:
        return
    print(n)
    print_numbers(n + 1)

def print_numbers2(n):
    if n < 1:
        return
    print_numbers2(n - 1)
    print(n)

print_numbers(1)
print_numbers2(10)


print("Fib(6) = {}".format(fib(6)))
print("Fact(5) = {}".format(fact(5)))