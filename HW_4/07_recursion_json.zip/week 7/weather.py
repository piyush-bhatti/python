import json

def load_simple_data():
    try:
        with open('weather.json') as f:
            data = json.load(f)
        current_temp = data['main']['temp'] - 273
        print("Current temperature: {:.2f}".format(current_temp))
    except:
        print("Error loading data")

def load_hist_data():
    from statistics import mean
    try:
        with open('hist_weather.json') as f:
            data = json.load(f)

        avg = mean(item["main"]["temp"] - 273 for item in data["list"])
        print("Avg temperature: {:.2f}".format(avg))
    except:
        print("Error loading data")

load_hist_data()